#include <windows.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <openssl/sha.h>
#include <wininet.h>
#pragma comment(lib, "wininet.lib")

std::string CalculateSHA256(const std::string& filePath) {
    std::ifstream file(filePath, std::ios::binary);
    if (!file) {
        return "";
    }
    
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    
    char buffer[4096];
    while (file.read(buffer, sizeof(buffer))) {
        SHA256_Update(&sha256, buffer, file.gcount());
    }
    SHA256_Update(&sha256, buffer, file.gcount());
    
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_Final(hash, &sha256);
    
    std::stringstream ss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        ss << std::hex << (int)hash[i];
    }
    return ss.str();
}

std::map<std::string, std::string> FetchHashList(const std::string& serverID) {
    std::map<std::string, std::string> hashList;
    HINTERNET hInternet = InternetOpen("AzauldUpdater", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hInternet) return hashList;
    
    std::string url = "http://yourserver.com/plist.txt";
    HINTERNET hConnect = InternetOpenUrl(hInternet, url.c_str(), NULL, 0, INTERNET_FLAG_RELOAD, 0);
    if (!hConnect) {
        InternetCloseHandle(hInternet);
        return hashList;
    }
    
    char buffer[4096];
    DWORD bytesRead;
    std::stringstream response;
    while (InternetReadFile(hConnect, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead) {
        buffer[bytesRead] = '\0';
        response << buffer;
    }
    
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);
    
    std::istringstream stream(response.str());
    std::string line;
    while (std::getline(stream, line)) {
        std::istringstream iss(line);
        std::string filename, hash;
        if (iss >> filename >> hash) {
            hashList[filename] = hash;
        }
    }
    return hashList;
}

bool DownloadFile(const std::string& fileUrl, const std::string& savePath) {
    HINTERNET hInternet = InternetOpen("AzauldUpdater", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hInternet) return false;
    
    HINTERNET hConnect = InternetOpenUrl(hInternet, fileUrl.c_str(), NULL, 0, INTERNET_FLAG_RELOAD, 0);
    if (!hConnect) {
        InternetCloseHandle(hInternet);
        return false;
    }
    
    std::ofstream outFile(savePath, std::ios::binary);
    if (!outFile) {
        InternetCloseHandle(hConnect);
        InternetCloseHandle(hInternet);
        return false;
    }
    
    char buffer[4096];
    DWORD bytesRead;
    while (InternetReadFile(hConnect, buffer, sizeof(buffer), &bytesRead) && bytesRead) {
        outFile.write(buffer, bytesRead);
    }
    
    outFile.close();
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);
    return true;
}

int main() {
    std::string serverID = "your_server_id";
    std::string rootFolder = "./";
    
    std::map<std::string, std::string> hashList = FetchHashList(serverID);
    if (hashList.empty()) {
        MessageBox(NULL, "Failed to fetch hash list!", "Azauld Game Guard", MB_ICONERROR | MB_OK);
        return 1;
    }
    
    std::vector<std::string> corruptedFiles;
    for (const auto& pair : hashList) {
        std::string filePath = rootFolder + pair.first;
        std::string calculatedHash = CalculateSHA256(filePath);
        
        if (calculatedHash.empty() || calculatedHash != pair.second) {
            std::cout << "[UPDATING] Downloading: " << pair.first << "\n";
            std::string fileUrl = "http://yourserver.com/data/patches/" + pair.first;
            if (DownloadFile(fileUrl, filePath)) {
                std::cout << "[SUCCESS] Updated: " << pair.first << "\n";
            } else {
                std::cout << "[FAILED] Unable to update: " << pair.first << "\n";
            }
        }
    }
    
    MessageBox(NULL, "Patch update complete!", "Azauld Game Guard", MB_ICONINFORMATION | MB_OK);
    return 0;
}
