# Sagaan-AntiCheat

[[My Website]](https://theherobrine9.wixsite.com/website/)

# Features
- Handle Creation Callback ( Process & Threads )
- Heartbeat System
- Overlay Scanner
- Driver Scanner ( WIP )
- Anti Debug
- Anti Kill / Suspend Threads
- Anti Injection
- Digital Signature Scanner
- Anti TestMode
- Signature Scanner

# TO-DO
- Properly Fix Driver Scanner
- A way that the module and usermode can communicate ( I added named pipe )
- Finding Hijacked Threads
- Checking IAT For Modification
- Checking for Test Mode Spoofer
- HWID System
- Checking Driver and DLL for any modifications ( MD5 Hash or anything of sort )
- Game Server Communication
- Stripping lsass and csrss handle permissions
- Checking for manual mapped drivers

# Notes
Feel free to use this however you like. If you have any issues or any problems, feel free to open up a issue in github. Note that i will be updating this along the way, and improving it along the days. For now, this work was made in about 4 days, so this could be a long project. Other then that, enjoy.

 
# System Portability 
- Only Tested On Windows 7 x64
- Meant for 64 bit OS and 32 bit Games ( 64 bit coming soon )

# Credits
https://github.com/mq1n/DLLThreadInjectionDetector/tree/master/DLLInjectionDetector
https://github.com/LordNoteworthy/al-khaser/tree/master/al-khaser/Anti%20Debug
https://github.com/osiris123/CDriver_Loader

Other credits are in the code and files named as "~ Owner"
