#include <windows.h>

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
        case WM_DESTROY:
            PostQuitMessage(0);
            break;
        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
    return 0;
}

void ShowSplashScreen() {
    HINSTANCE hInstance = GetModuleHandle(NULL);
    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "AzauldSplash";
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);

    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(
        WS_EX_TOPMOST, "AzauldSplash", "Azauld AntiCheat", WS_POPUP | WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, 400, 300,
        NULL, NULL, hInstance, NULL
    );

    HDC hdc = GetDC(hwnd);
    
    // Load BMP image
    HBITMAP hBitmap = (HBITMAP)LoadImage(NULL, "GameGuard/azauld.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
    if (hBitmap) {
        HDC hdcMem = CreateCompatibleDC(hdc);
        SelectObject(hdcMem, hBitmap);
        BITMAP bmp;
        GetObject(hBitmap, sizeof(BITMAP), &bmp);
        StretchBlt(hdc, 0, 0, 400, 300, hdcMem, 0, 0, bmp.bmWidth, bmp.bmHeight, SRCCOPY);
        DeleteDC(hdcMem);
        DeleteObject(hBitmap);
    } else {
        TextOut(hdc, 150, 130, "Loading...", 10);
    }
    
    ReleaseDC(hwnd, hdc);
    Sleep(3000);  // Tampilkan selama 3 detik
    DestroyWindow(hwnd);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    ShowSplashScreen();
    return 0;
}
