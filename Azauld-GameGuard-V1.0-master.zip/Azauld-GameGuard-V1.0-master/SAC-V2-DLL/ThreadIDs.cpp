#include "ThreadIDs.h"

namespace ThreadID
{
	DWORD TIDMain;
	DWORD TIDAntiDebug;
	DWORD TIDNamedPipe;
	DWORD TIDCheckUsermodePrcoess;
}